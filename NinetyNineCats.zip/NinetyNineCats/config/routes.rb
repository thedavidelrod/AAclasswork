Rails.application.routes.draw do
resources :cats
end

