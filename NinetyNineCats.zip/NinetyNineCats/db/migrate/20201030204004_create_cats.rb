class CreateCats < ActiveRecord::Migration[5.2]
  def change
    create_table :cats do |t|
      t.date :birth_date, null: false
      t.string :color, null: false
      t.string :name, null: false
      t.string :sex, null: false, limit: 1
      t.text :description, null: false
      t.timestamps


      #add_column(:users, :picture, :binary, limit: 2.megabytes)
      #add_column(:articles, :status, :string, limit: 20, default: 'draft', null: false)
    end
  end
end
