class CatRentalRequest < ApplicationRecord
  validates :cat_id, :start_date, :end_date, :status, presence: true 


  belongs_to :cat


  def overlapping_requests
    .select(:start_date, :end_date)
    .joins(:cat)
    .where(cat_id: {cat: params[:id]})
  end 








end
