class Cat < ApplicationRecord
  validates :birth_date, :color, :name, :sex, :description, presence: true
  validates :sex, inclusion: ["M","F"]
  validates :color, inclusion: ["black", "orange", "calico","white","others"]

  has_many :rentals,
  foreign_id: :cat_id,
  class_name: :CatRentalRequest
  dependent: :destroy

end
