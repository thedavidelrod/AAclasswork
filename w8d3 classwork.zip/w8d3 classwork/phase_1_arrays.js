Array.prototype.uniq = function() {
    let result = [];
    for (i=0; i < this.length; i++) {
        let char = this[i];
        if (!result.includes(char)) {
            result.push(char)
        }
    }
    return result
}

//console.log([1,2,3,3,3,3].uniq())

Array.prototype.twoSum = function() {
    let result = [];
        for (i = 0; i < this.length -1; i++) {
            for (j = i+1; j < this.length; j++) {
                if (this[i] + this[j] === 0) {
                    result.push([i,j]);
                }
            }
        }
        return result
}

//console.log([1,2,3,3,3,3,-3,1,-2].twoSum())

Array.prototype.transpose = function() {
    let result = [];

        for (let i = 0; i < this[0].length; i++) {
            result.push([])

            for (let j = 0; j < this.length; j++) {
                let ele1 = this[j][i];
                
                result[i].push(ele1)
            }
        }
        return result
}

//console.log([[1,1],[2,2],[3,3]].transpose())


Array.prototype.myEach = function(callback) {
    for (i=0; i < this.length; i++) {
        callback(this[i])
    }    
}

Array.prototype.myMap = function(callback) {
    let result = [];
    this.myEach(function(ele) {
        result.push(callback(ele))
    });
    return result
}

const doubler = function(ele) {
    return ele * 2;
}

Array.prototype.myReduce = function(callback, initialValue) {
    if (!initialValue) {
        initialValue = this[0] 
        this.slice(1).myEach(
            function(ele) {
                initialValue = callback(initialValue, ele)
            }
    )
    } else {
    this.myEach(
        function(ele) {
           initialValue = callback(initialValue, ele)
        }
    )
    }
    return initialValue
    
}


// // without initialValue
// console.log(
// [1, 2, 3].myReduce(function(acc, el) {
//     return acc + el;
//   })) // => 6
  
// // with initialValue
// console.log(
// [1, 2, 3].myReduce(function(acc, el) {
// return acc + el;
// }, 25)) // => 31

Array.prototype.bubbleSort = function() {
    let result = this
    let sorted = false

    while (!sorted) {
        sorted = true
        for (i = 0; i < result.length -1; i++) {
            if (result[i] > result[i +1]) {
                let temp = result[i] 
                result[i] = result[i + 1]
                result[i+1] = temp

                sorted = false
            }
        }
    }
    return result
}

// console.log([1,4,6,8,9,3,4,56,7,1,67].bubbleSort())

String.prototype.substrings = function() {
    let result = []
    for (i=0; i < this.length; i++) {
        for (j=i+1; j <= this.length; j++) {
            result.push(this.slice(i,j))
        }
    }
    return result
}

// console.log('hello'.substrings())

function range(start, end) {
    
    if (start === end) {
        return [start];
    } 
        return [start].concat(range(start + 1, end))
}

//console.log(range(3,9))

function sumRec(array) {
    if (array.length < 1) {
        return 0
    } 
    return sumRec(array.slice(1)) + array[0]
}

//console.log(sumRec([4,6,4,1]))

function exponentOne(base, exp) {
    if (exp === 0) {
        return 1
    } 
    return exponentOne(base, exp -1) * base
}

//.console.log(exponentOne(2,3))

function exponentTwo(base, exp) {
     if (exp === 0) {
        return 1
    } 
    if (exp === 1) {
        return base
    }
    if (exp % 2 === 0) {
        return exponentTwo(base, exp / 2) ** 2
     } else {
         return base * exponentTwo(base, (exp -1) / 2) ** 2
     }
}

// console.log(exponentTwo(2,3))
// console.log(exponentTwo(2,4))

function fibonacci(n) {
    if (n === 1) {
        return [1]
    } 
    if (n === 2) {
        return [1,1]
    } 
    let last = fibonacci(n-1)
    return last.push(last[last.length-1]+last[last.length-2]) 
}

console.log(fibonacci(2))