class Api::TodosController < ApplicationController

def index 
    @todos = Todolist.all
    render :index
end

def show
  render json: Todolist.find(params[:id])
end

def create
  @todo = Todolist.new(todo_params)
  if @todo.save
    render json: @todo
  else
    render json: @todo.errors.full_messages, status: 422
  end
end

def update
end

def destroy
end

def todo_params
    params.require(:todo).permit(:title,:body,:done)
end


end#!


