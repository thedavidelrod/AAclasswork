import { createStore } from 'redux';
import rootsReducer from './reducers/root_reducer.js'


const configureStore = (preloadedState = {}) => {
    return createStore(rootsReducer, preloadedState);
}

export default configureStore;


