import { combineReducers } from 'redux';
import reducer from '/other_file/frontend/reducers/todos_reducer.js';




const rootsReducer = combineReducers({
    todo: reducer
})


export default rootsReducer