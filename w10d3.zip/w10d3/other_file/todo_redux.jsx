import React from 'react'
import ReactDOM from 'react-dom'
import configureStore from './store/store'
import { receiveTodo } from '/actions/todo_action'



document.addEventListener('DOMContentLoaded', ()=> {
    const root = document.getElementById("root");
    const store = configureStore();
    
    // TESTING
    window.store = store;
    window.receiveTodo = receiveTodo;
    // END TESTING
    ReactDOM.render(<h1> Todo App </h1>, root);


})


