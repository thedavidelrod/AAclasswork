


export const receiveTodo = (id, type, title, body, done) => {
    return {
        id:,
        type: RECEIVE_TODOS,
        title:,
        body:, 
        done: false
        
    }
}