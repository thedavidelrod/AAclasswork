import React from 'react'
import TeaIndex from './tea_index'



class TeaForm extends React.Component{

    constructor(props){
        super(props);

        this.state = {
            id: Math.floor(Math.random() * 1000000),
            flavor: '',
            amount: ''
        }

        this.updateFlavor = this.updateFlavor.bind(this);
        this.updateAmount = this.updateAmount.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }


    updateFlavor(e){
        this.setState({flavor: e.target.value})
    }
    updateAmount(e) {
        this.setState({ amount: e.target.value })
    }

    handleSubmit(e){

    }



    render(){
        return(
            <div>
                <h1> The Form</h1>
                <form onSubmit={this.handleSubmit}>
                    <lable>Flavor:
                        <input type="text"  > </input>
                    </lable>


                </form>



            </div>



        )

    }

}


export default TeaForm;