import React from 'react';
import TeaIndexContainer from './teas/tea_index_container';

const App = () => {

    return (
        <div>
            <TeaIndexContainer />
        </div>
    );
}

export default App;