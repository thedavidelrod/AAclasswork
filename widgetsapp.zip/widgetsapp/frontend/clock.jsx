import React, { Component } from 'react'
// import './clock.css';

export default class Clock extends Component {
  constructor(props) {
    super(props);
    let date =  new Date();
    date = date.toString();
    let arr = date.split(" ")
    let d = arr.slice(0, 4).join(" ")
    let t = arr.slice(4, 5)[0]

    this.state = {
      date: new Date(),
      day: d,
      time: t,
    }
    this.tick = this.tick.bind(this);
  }
  componentDidMount(){
    setInterval(() => {
      this.tick() 
    }, 1000);
  }

  tick() {
    let date =  new Date();
    date = date.toString();
    let arr = date.split(" ")
    let d = arr.slice(0, 4).join(" ")
    let t = arr.slice(4, 5)[0]

    this.setState({
      date: new Date(),
      day: d,
      time: t
    })
  }

  render() {
    return (
      <div
        className="Clock"
        style={{
            color: 'yellow',
          fontFamily: "righteous",
          display: "flex",
          justifyContent: "space-around",
          backgroundColor: "blue",
          margin: "0px auto",
          maxWidth: "500px",
          height: 130,
          padding: 10,
          border: "1px solid black",
          borderRadius: 5,
          alignItems: "flex-start",
          
        }}
      >
        <div>

        <h1 className="time">TIME </h1>
        <span>{this.state.day.toString()}</span>
        </div>
        <div>
        <h1 className="date">DATE</h1>
        <span>{this.state.time.toString()}</span>
        </div>
      </div>
    );
  }
}


