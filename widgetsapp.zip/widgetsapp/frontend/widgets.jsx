import React from 'react';
import ReactDOM from 'react-dom';
import App from './app';
import AutoComplete from './autocomplete';
import Card from './card'
// import './index.css'




document.addEventListener('DOMContentLoaded', () => {
    const root = document.getElementById('root')
    ReactDOM.render(<App />, root)
});