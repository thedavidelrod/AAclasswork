
import React, { Component } from 'react'

export default class Tabs extends Component {
    constructor(props) {
        super(props) 
        this.state = {
            currentTab: "One"

        }
    }

    handleOne(){
        this.setState( {currentTab:"One"})
    }

    handleTwo() {
this.setState( {currentTab:"Two"})
    }

    handleThree() {
        this.setState( {currentTab:"Three"})
    }
 
  render() {
    return (
      <div
      className = 'tabs'>
        <button onClick= {() => this.handleOne()}>One</button>
        <button onClick= {() => this.handleTwo()}>Two</button>
        <button onClick= {() => this.handleThree()}>Three</button>
    <h1>{this.state.currentTab}</h1>
      </div>
    )
  }
}
