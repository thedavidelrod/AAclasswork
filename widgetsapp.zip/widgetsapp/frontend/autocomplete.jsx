import React, { Component } from 'react'

export default class Autocomplete extends Component {
   
    constructor(props) {
        super(props);
        this.array = ['abcdef','xyz','knmf','coool'];
        this.state = {currentWord: '', wordArray: this.array};

    }
    search() {
        console.log("current", this.state.currentWord)
        let array = this.state.wordArray.filter(ele => ele.includes(this.state.currentWord))
        console.log(array)
        this.setState({wordArray: array})
    }

    handleChange(e) {
      e.preventDefault()
      
        this.setState({ currentWord: e.target.value }, this.search.bind(this));
    }
  render() {
    return (
      <div>
          
        <input type='text' onChange= {(e) => this.handleChange(e)} value= {this.state.currentWord} />
        <ul>
            {this.state.wordArray.map((ele, idx) => <li key= {idx}>
                {ele}
            </li>
                )}
        </ul>
      </div>
    )
  }
}
