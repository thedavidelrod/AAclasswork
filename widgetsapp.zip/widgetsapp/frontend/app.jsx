import React from 'react';
import Autocomplete from './autocomplete';
import Clock from './clock';
import Card from './card';
import Tabs from './tabs';
import Weather from './weather'
export default function App() {
  return <div>
    <Clock />
     <Tabs />
     <Weather />
     <Autocomplete />
     <Card />
  </div>;
}