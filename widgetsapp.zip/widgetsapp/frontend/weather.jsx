//api.openweathermap.org/data/2.5/weather?q=Juneau&appid=cc94b5ed3ac735cd55ece932702c94dd

import React, { Component } from "react";

export default class Weather extends Component {
  constructor(props) {
    super(props);
    this.state = { location: "", temprature: 0 };
  }
  componentDidMount() {
    const location = "Juneau";
    this.setState({ location }, this.getTemp.bind(this));
  }

  getTemp() {
    $.ajax({
      url: `https://api.openweathermap.org/data/2.5/weather?q=Juneau&units=imperial&appid=cc94b5ed3ac735cd55ece932702c94dd`,
      method: "GET",
    }).then((res) => {
      let temp = res["main"]["temp"];
      console.log(temp);
      this.setState({ city: this.state.location, temprature: temp });
    });
  }

  render() {
    return (
      <div>
        <p>getting weather</p>
        <h2> {this.state.city}</h2>
        <h2> {this.state.temprature}</h2>
      </div>
    );
  }
}
